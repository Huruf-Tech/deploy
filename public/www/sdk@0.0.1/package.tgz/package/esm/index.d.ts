/**
 * Copyright © Huruf Tech 2026
 *
 * This is a generated file. Do not edit the contents of this file!
 */
import { BaseSDK } from "./base.js";
import { domainsModule } from "./modules/domains.js";
import { projectGroupsModule } from "./modules/projectGroups.js";
import { projectsModule } from "./modules/projects.js";
import { billingModule } from "./modules/billing.js";
import { billingAdminModule } from "./modules/billingAdmin.js";
import { plansModule } from "./modules/plans.js";
import { gitIntegrationsModule } from "./modules/gitIntegrations.js";
import { githubHooksModule } from "./modules/githubHooks.js";
import { templatesModule } from "./modules/templates.js";
import { variablesModule } from "./modules/variables.js";
import { homeModule } from "./modules/home.js";
import { indexModule } from "./modules/index.js";
import { agentsModule } from "./modules/agents.js";
import { networksModule } from "./modules/networks.js";
import { registriesModule } from "./modules/registries.js";
import { serversModule } from "./modules/servers.js";
import { storagesModule } from "./modules/storages.js";
import { streamsModule } from "./modules/streams.js";
import { alertEventsModule } from "./modules/alertEvents.js";
import { alertRulesModule } from "./modules/alertRules.js";
import { controlPlaneModule } from "./modules/controlPlane.js";
import { wellKnownModule } from "./modules/.well-known.js";
import { accessControlModule } from "./modules/accessControl.js";
import { accessControlPoliciesModule } from "./modules/accessControlPolicies.js";
import { apiKeysModule } from "./modules/apiKeys.js";
import { authModule } from "./modules/auth.js";
import { envsModule } from "./modules/envs.js";
import { imageKitModule } from "./modules/imagekit.js";
import { meModule } from "./modules/me.js";
import { oauthModule } from "./modules/oauth.js";
import { oauthClientsModule } from "./modules/oauthClients.js";
import { tenantInvitesModule } from "./modules/tenantInvites.js";
import { tenantMembersModule } from "./modules/tenantMembers.js";
import { tenantMembershipsModule } from "./modules/tenantMemberships.js";
import { tenantsModule } from "./modules/tenants.js";
import { usersModule } from "./modules/users.js";
import { walletLedgersModule } from "./modules/walletLedgers.js";
import { walletsModule } from "./modules/wallets.js";
import { essentialsEntry } from "./plugins/essentials/entry.js";
export declare class ThunderSDK extends BaseSDK {
    protected static _actionsList?: string[];
    protected static _moduleNames: string[];
    static domains: ReturnType<typeof domainsModule>;
    static projectGroups: ReturnType<typeof projectGroupsModule>;
    static projects: ReturnType<typeof projectsModule>;
    static billing: ReturnType<typeof billingModule>;
    static billingAdmin: ReturnType<typeof billingAdminModule>;
    static plans: ReturnType<typeof plansModule>;
    static gitIntegrations: ReturnType<typeof gitIntegrationsModule>;
    static githubHooks: ReturnType<typeof githubHooksModule>;
    static templates: ReturnType<typeof templatesModule>;
    static variables: ReturnType<typeof variablesModule>;
    static home: ReturnType<typeof homeModule>;
    static index: ReturnType<typeof indexModule>;
    static agents: ReturnType<typeof agentsModule>;
    static networks: ReturnType<typeof networksModule>;
    static registries: ReturnType<typeof registriesModule>;
    static servers: ReturnType<typeof serversModule>;
    static storages: ReturnType<typeof storagesModule>;
    static streams: ReturnType<typeof streamsModule>;
    static alertEvents: ReturnType<typeof alertEventsModule>;
    static alertRules: ReturnType<typeof alertRulesModule>;
    static controlPlane: ReturnType<typeof controlPlaneModule>;
    static wellKnown: ReturnType<typeof wellKnownModule>;
    static accessControl: ReturnType<typeof accessControlModule>;
    static accessControlPolicies: ReturnType<typeof accessControlPoliciesModule>;
    static apiKeys: ReturnType<typeof apiKeysModule>;
    static auth: ReturnType<typeof authModule>;
    static envs: ReturnType<typeof envsModule>;
    static imageKit: ReturnType<typeof imageKitModule>;
    static me: ReturnType<typeof meModule>;
    static oauth: ReturnType<typeof oauthModule>;
    static oauthClients: ReturnType<typeof oauthClientsModule>;
    static tenantInvites: ReturnType<typeof tenantInvitesModule>;
    static tenantMembers: ReturnType<typeof tenantMembersModule>;
    static tenantMemberships: ReturnType<typeof tenantMembershipsModule>;
    static tenants: ReturnType<typeof tenantsModule>;
    static users: ReturnType<typeof usersModule>;
    static walletLedgers: ReturnType<typeof walletLedgersModule>;
    static wallets: ReturnType<typeof walletsModule>;
    static plugins: {
        essentials: typeof essentialsEntry;
    };
    static getModuleNames(): string[];
    static getModule(name: string): Record<string, (data: unknown) => Promise<unknown>>;
    static hasModule(name: string): boolean;
    static getMetadata(module: object | string): Record<string, unknown> | undefined;
    static hasMetadata(module: object | string): boolean;
    static getGroup(module: object | string): string | undefined;
    static hasGroup(module: object | string): boolean;
    static listActions(moduleName?: string): string[];
}
//# sourceMappingURL=index.d.ts.map