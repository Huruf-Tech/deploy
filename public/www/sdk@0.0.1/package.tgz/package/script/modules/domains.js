"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.domainsModule = void 0;
const path_to_regexp_1 = require("path-to-regexp");
const domainsModule = (sdk) => {
    const type = {};
    const methods = {
        type,
        list(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "list");
                const method = "get";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        create(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "create");
                const method = "post";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        appDomainInfo(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "appDomainInfo");
                const method = "get";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/app");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        addTestDomain(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "addTestDomain");
                const method = "post";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/app");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        check(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "check");
                const method = "post";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/:id/check");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        cloudflareConnection(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "cloudflareConnection");
                const method = "get";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/cloudflare/connection");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        connectCloudflareToken(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "connectCloudflareToken");
                const method = "put";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/cloudflare/connection");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        disconnectCloudflare(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "disconnectCloudflare");
                const method = "delete";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/cloudflare/connection");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        authorizeCloudflare(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "authorizeCloudflare");
                const method = "get";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/cloudflare/authorize");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        cloudflareCallback(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "cloudflareCallback");
                const method = "get";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/cloudflare/callback");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        setUpCloudflare(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "setUpCloudflare");
                const method = "post";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/:id/cloudflare");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
        del(data) {
            return sdk.resolveAxiosResponse(async () => {
                sdk.checkPermission("domains", "del");
                const method = "delete";
                const toPath = (0, path_to_regexp_1.compile)("domains/api/:id");
                const requestPayload = {
                    method,
                    url: toPath(sdk.resolvePathParams(data?.params)),
                    params: data?.query,
                    data: data?.body,
                    signal: data?.signal,
                    ...(data?.axiosConfig
                        ? sdk.resolveAxiosConfig(data.axiosConfig)
                        : undefined),
                };
                sdk.log("Sending Request:", requestPayload);
                const res = await sdk._axios.request(requestPayload);
                return res;
            }, data);
        },
    };
    methods.list.__scope = "domains";
    methods.create.__scope = "domains";
    methods.appDomainInfo.__scope = "domains";
    methods.addTestDomain.__scope = "domains";
    methods.check.__scope = "domains";
    methods.cloudflareConnection.__scope = "domains";
    methods.connectCloudflareToken.__scope = "domains";
    methods.disconnectCloudflare.__scope = "domains";
    methods.authorizeCloudflare.__scope = "domains";
    methods.cloudflareCallback.__scope = "domains";
    methods.setUpCloudflare.__scope = "domains";
    methods.del.__scope = "domains";
    sdk["_moduleGroup"].set(methods, "Applications");
    return methods;
};
exports.domainsModule = domainsModule;
